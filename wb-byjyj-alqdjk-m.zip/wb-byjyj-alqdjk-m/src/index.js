/**
 * @author {娄露红}({WB085725})
 * @version 0.0.1
 */
define(function(require) { // eslint-disable-line no-unused-vars

    var lazy = require('kg/km-lazyload');
    var XCtrl = require('tbc/m-xctrl/1.2.1/index');
    var login = require('mtb/lib-login');
    var SnsWeitaoFollow = require('kg/sns-weitao-follow/0.1.0/')
    var itemTpl = require('./item.jst.html');
    var itemTpl1 = require('./expert.jst.html');
    var mtop = require('kg/km-mtop');
    var windvane = require('mtb/lib-windvane');
  function Mod() {
    this.init.apply(this, arguments);
  }

  Mod.prototype = {
    /**
    * 入口
    * @param dom 模块根节点
    * @param conf 数据描述，为空说明已渲染
    */
    init: function(container, conf) {
        var self = this;
        self._node = $(container);
        self.OpenWin = {};
        self.OpenWin.open = function(url) {
            if (window.navigator.userAgent.match(/WindVane/i)) {
                var params = {
                    // 要打开的页面地址
                    url: url
                };
                windvane.call('Base', 'openWindow', params, function(e) {
                }, function(e) {
                    location.href = url;
                });
            } else {
                location.href = url;
            }
        };
        if (!conf) {
            conf = $.parseJSON(self._node.find('.J_ModuleData').html());
        }
        self._conf = conf;
        self.loadData(conf);
        self.jkData(conf);
        self._node.on('click', '.by_link', function(e){
            btnHref = $(e.currentTarget).attr('href');
            self.OpenWin.open(btnHref);
            return false;
        })
        new SnsWeitaoFollow({
          type: 2, // 显示关注样式两种，1 背景 2 无背景
          target: '.J_Follow2', //容器
          isBatch: true, //是否批量去请求
          followColor: '#ffb901', //关注颜色
          followedColor: '#ffb901' //已关注颜色
        });
    },
    jkData:function(conf){
        var self=this;
        var newData={};
        $.each(self._node.find('.by_data'),function(i,item){
            var id = $(item).attr('data-id');
            var userId = $(item).attr('data-user-id');
            $.ajax({
                url:'//www.jiyoujia.com/youjia/json/getAlbumDetailInfo',
                dataType:'jsonp',
                data:{
                    id:id,
                    userid:userId
                },
                success:function(data){
                    // newData={data}
                    newData={'items':data}
                    console.log(newData)
                    $(item).html(itemTpl1({items:newData}));
                    
                    self._node.find('.J_LazyLoad').lazyload({
                        offsetY: 100
                    });
                }
            });
        })
    },
    // 加载数据
    loadData: function(conf) { // eslint-disable-line no-unused-vars
        var self = this;
        //XCtrl逻辑，参考文档：http://yongyi.alidemo.cn/xctrl-doc/_book/use/how.html
        XCtrl.dynamic(conf, "items", function (data) {
            // console.log(itemTpl(data))
            self._node.find(".by_c").html(itemTpl(data));
            
        });

    },
    // 事件绑定
    bindEvent: function() {

    }
  };

  return Mod;

});
