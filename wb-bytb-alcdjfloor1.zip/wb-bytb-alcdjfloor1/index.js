/**
 * @author {娄露红}({WB085725})
 * @version 0.0.1
 */

KISSY.add(function(S, require) {
  var Node = require('node'),
    XTemplate = require('tms/xtemplate'),
    DataLazyload = require('kg/datalazyload/6.0.5/index'),
    $ = Node.all,
    IO = require('io'),
    Countdown = require('kg/countdown/6.0.2/index'),
    XCtrl = require('market/xctrl'),
    mtop = require('./lib/mtop/');

  lib.mtop.config.prefix = 'api';   // mtop的前缀
  lib.mtop.config.subDomain = 'm';       // mtop的子域
  lib.mtop.config.mainDomain = 'taobao.com';   // mtop的主域

  var itemTmpl = require("./item-xtpl");
  var itemTmpl1 = require("./item1-xtpl");
  var itemTmpl2 = require("./item2-xtpl");

  function Mod() {
    this.init.apply(this, arguments);
  }

  Mod.prototype = {
    /**
     * 入口
     * @param dom 模块根节点
     * @param conf 数据描述，为空说明已渲染
     */
    init: function(container, conf) {
      var self = this;
      self._node = Node.one(container); //代表当前这个模块的父级
      conf = conf || self._node.one(".J_conf").val();
      self.conf = conf;
      //self.error可用于记录模块的异常 并且在jstracker平台查看 self.error('api错误')
      new IO({
        url: "//t.alicdn.com/t/gettime",
        dataType: "jsonp",
        success: function(d) {
          self.loadData('banner', function(data) {
            //数据处理，模板渲染
            var $box = self._node.one('.J_Banner');
            self.render(itemTmpl, data, $box);

          });
          self.loadData('find', function(data) {
            self.renderFind(data);
          });
          self.loadData('shangou', function(data) {
            self.nowms = d.time * 1000;
            self.correctItems = getCorrectItems(data.items, self.nowms);
            self.rendrtime(self.correctItems);
            //模板完绑定事件
            self.bindShangou(self.correctItems);
          });

          //懒加载
          new DataLazyload({
            container: self._node
          }).refresh();
        }
      });
      self._node.find('.by_top').removeClass('cdj-loading');
      self._node.find('.by_right').removeClass('cdj-loading');
      self._node.find('.by_bottom').removeClass('cdj-loading');
    },
    // 发现模块
    renderFind: function(data) {
      var self = this;
      var $box = self._node.one('.J_FaxianList');
      self.render(itemTmpl1, data, $box);
    },
    rendrtime: function(ndata) {
      var self = this;
      var $box = self._node.find('#J_ShanGouTeMaiItems1');
      self.render(itemTmpl2, ndata, $box);
    },
    //加载数据
    loadData: function(type, callback) {
      var self = this, conf;

      if (type === 'banner') {
        conf = {
          "moduleinfo": {},
          "items": [{
            "data_para": {"tce_vid": "1", "env": "pre", "tce_sid": 459526},
            "data_type": "tceinner",
            "tms_type": "jsonp"
          }],
          "squareItems": [{
            "data_para": {"tce_vid": "2", "env": "pre", "tce_sid": 456900},
            "data_type": "tceinner",
            "tms_type": "jsonp"
          }],
          "clbb": [{
            "data_para": {"tce_vid": "2", "env": "pre", "tce_sid": 456901},
            "data_type": "tceinner",
            "tms_type": "jsonp"
          }]
        };

        var mergedData = {}, count = 0;

        XCtrl.dynamic(conf, 'items', function(data) {
          ++count;
          mergedData.items = data.items;

          if (count >= 3) {
            callback(mergedData);
          }
        });

        XCtrl.dynamic(conf, 'squareItems', function(data) {
          ++count;
          mergedData.squareItems = data.squareItems;

          if (count >= 3) {
            callback(mergedData);
          }
        });
        XCtrl.dynamic(conf, 'clbb', function(data) {
          ++count;
          mergedData.clbb = data.clbb;

          if (count >= 3) {
            callback(mergedData);
          }
        });
      } else if (type === 'find') {
        mtop.request({
          // 通用参数
          api: 'mtop.taobao.shuma.getFindList', // 必须
          v: '1.0',  // 必须
          data: {
            catId: '',
            pageNum: '1',
            pageSize: '3'
          }, // 必须（注意1）
          ecode: 0,   // 必须（注意2）
          type: 'GET',   // 非必须。请求类型（GET/POST），默认是GET
          dataType: 'jsonp', // 非必须。数据类型（jsonp/json），默认jsonp
          timeout: 20000 // 非必须。接口超时设置，默认为20000ms
        }, function(data) {
          callback({items: data.data.data});
        }, function(err) {
          console.log(err);
        });
      } else if (type === 'shangou') {
        conf = {
          "moduleinfo": {"moreLink": "//market.m.taobao.com/markets/cdj/shangou#guid-154759"},
          "items": [{
            "data_para": {"tce_vid": "0", "env": "pre", "tce_sid": 439541},
            "data_type": "tceinner",
            "tms_type": "jsonp"
          }]
        };
        XCtrl.dynamic(conf, 'items', function(data) {
          if (data.items && data.items.length > 4) {
            data.items.length = 4;
          }
          callback(data);
        });
      }
    },
    // 渲染指定模板与节点
    render: function(tmplModule, data, box) {
      var self = this;
      var itemTpl = new XTemplate(tmplModule),
        itemHtml = itemTpl.render(data);
      box.html(itemHtml);
      //懒加载
      new DataLazyload({
        container: self._node
      }).refresh();
    },
    // 绑定闪购事件
    bindShangou: function(correct) {
      var self = this;

      $('#J_ShanGouTeMaiItems1').removeClass('cdj-loading');

      if (correct.type == '2') {
        /*$('#J_SGTMCountDown').html('已经结束啦！');*/
        $('.cdj-main-shangoutemaixzp .module-wrap').css('display', 'none');
        return;
      }

      var txtMap = {
        '0': '距开始剩余时间',
        '1': '距结束剩余时间'
      };

      $('#J_SGTMCountDown1 span').html(txtMap[correct.type]);

      Countdown({
        el: $('#J_SGTMCountDown1'),
        //stopPoint: parseDate('2015-09-06 22:00:00:00').getTime(),    // unix时间戳
        leftTime: correct.remain / 1000,      // or 剩余毫秒
      });

      var time1 = setInterval(function() {
        if ($('#J_SGTMCountDown1').text() == '距结束剩余时间：00天00时00分001秒') {
          $('.cdj-main-shangoutemaixzp .module-wrap').css('display', 'none');
          clearInterval(time1);
        }
      }, 2000);
    }
  };

  return Mod;

  function parseDate(dateStr) {
    // console.log(dateStr)
    var dateRegExp = /^(\d{4})\-([0-1]?[0-9])\-([0-3]?[0-9])\s+([0-2]?[0-9])\:([0-5]?[0-9])\:([0-5]?[0-9])(?:\:(\d{1,3}))?/;
    var matched = dateStr.match(dateRegExp);

    if (matched) {
      return new Date(
        parseInt(matched[1]),
        parseInt(matched[2]) - 1,
        parseInt(matched[3]),
        parseInt(matched[4]),
        parseInt(matched[5]),
        parseInt(matched[6]),
        parseInt(matched[7] || 0)
      );
    }
    return new Date();
  }

  // 获得正确的商品，剩余时间，状态（即将，正在，结束）
  function getCorrectItems(items, now) {
    // 开始时间升序
    items.sort(function(a, b) {
      return parseDate(a.item_content_start_time).getTime() - parseDate(b.item_content_start_time).getTime();
    });
    var tt = [];
    var target = {
      remain: 0,
      type: '0',
      items: null
    };
    for (var i = 0; i < items.length; i++) {
      var start = parseDate(items[i].item_content_start_time).getTime();
      var end = parseDate(items[i].item_content_end_time).getTime();
      var n = parseInt(parseDate(items[i].item_content_start_time).getFullYear());
      var y = parseInt(parseDate(items[i].item_content_start_time).getMonth() + 1);
      var r = parseInt(parseDate(items[i].item_content_start_time).getDate());
      var hh = n + '/' + y + '/' + r + ' ' + '00:00:00';
      var ksr = new Date(hh).getTime();
      if (ksr <= now && now < start) {
        items[i].zt = 1;
        tt.push(items[i]);
      } else if (now >= start && now < end) {
        items[i].zt = 2;
        tt.push(items[i]);
      }
    }

    if (tt.length == 0) {
      $('.cdj-main-shangoutemaixzp .module-wrap').css('display', 'none');
    }
    target.items = tt;
    //因为是按开始最早到最晚排列所以第一个是最早开始
    var start = parseDate(tt[0].item_content_start_time).getTime();
    var n = parseInt(parseDate(tt[0].item_content_start_time).getFullYear());
    var y = parseInt(parseDate(tt[0].item_content_start_time).getMonth() + 1);
    var r = parseInt(parseDate(tt[0].item_content_start_time).getDate());
    var hh = n + '/' + y + '/' + r + ' ' + '00:00:00';
    var ksr = new Date(hh).getTime();
    var end = null;

    function ed() {
      target.items.sort(function(a, b) {
        return parseDate(a.item_content_end_time).getTime() - parseDate(b.item_content_end_time).getTime();
      });
      end = parseDate(target.items[target.items.length - 1].item_content_end_time).getTime();
    }//让数据按结束时间从小到到排列 这样最后一个数据就是当天最晚的时间
    ed();
    // 未开始
    if (ksr <= now && now < start) {
      target.type = '0';
      target.remain = start - now;
      // 进行中
    } else if (start <= now && now < end) {
      target.type = '1';
      target.remain = end - now;
      // 还有促销，进入下一个循环
    } else if (i + 1 < items.length) {
      // 结束了
    } else {
      target.type = '2';
    }
    return target;
  }
});
