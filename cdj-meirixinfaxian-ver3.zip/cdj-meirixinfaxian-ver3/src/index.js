/**
 * @author 龙喜
 * @version 0.0.1
 */

define(function(require) {
  var jst = require('./items.jst.html');
  var XCtrl = require('kg/m-xctrl');

  require('mtb/lib-windvane');
  require('kg/km-lazyload');

  var queries = getQuery();
  var itemId = queries.itemId;
  var debug = queries.debug === 'true';

  function Mod() {
    this.init.apply(this, arguments);
  }

  Mod.prototype = {
    init: function($container, conf) {
      var self = this;

      self.$container = $container;
      self.conf = conf || (conf = JSON.parse($('.J_FaxianData').html()));
      self.currentPage = 1;
      self.loading = false;

      self.bindEvent();

      if (!self.conf.moduleinfo.showHeader) {
        window.cdjItem = {
          // 宝贝渲染
          render: function(items, mtop) {
            if (self.catId !== mtop.data.catId) {
              var man = getItemByKV(self.conf.custom, 'index', mtop.data.catId || 0);

              if (man) {
                items.manEntrance = man.manEntrance;
                items.slogan = man.slogan;
                self.catId = man.catId;
              }
            }

            //第一页
            self.render(items, true);
            // 没有更多设置为false
            self.nomore = false;
            //第二页开始计算
            self.currentPage = 2;
            self.mtop = mtop;
            self.loading = false;
          }
        };
      }
    },
    loadData: function(callback) {
      if (!this.conf.moduleinfo.showHeader && !this.mtop) {
        return;
      }

      var self = this;
      var conf = self.conf;
      if (self.key) {

      } else {
        if (!conf) {
          self.$container.css('padding', '50px');
          return;
        }

        var finalData = conf.manualData || [];    // 人工和 TCE 混合数据

        delete conf.manualData;

        var copy = $.merge(true, conf);

        if (self.mtop) {
          //渲染
          var data = $.merge({
            pageNum: self.currentPage++,
            keyword: 'itemId:' + itemId
          }, self.mtop.data);

          lib.mtop.request({
            // 通用参数
            api: self.mtop.api, // 必须
            v: '1.0',  // 必须
            data: data, // 必须（注意1）
            ecode: 0,   // 必须（注意2）
            type: 'GET',   // 非必须。请求类型（GET/POST），默认是GET
            dataType: 'jsonp', // 非必须。数据类型（jsonp/json），默认jsonp
            timeout: 20000 // 非必须。接口超时设置，默认为20000ms
          }, function(data) {
            callback(data.data[self.mtop.key]);
            // 成功回调
          }, function(err) {
            // 失败回调
          });
        } else {
          XCtrl.dynamic(copy, 'tceData', function(data) {
            callback(finalData.concat(data.tceData));
          }, {
            pageNum: self.currentPage++,
            pageSize: 10 - finalData.length
          });
        }

        if (!copy.tceData) {
          setTimeout(function() {
            if (!self.$container.find('.J_MeiRiXinFaXianItems .item').length) {
              callback([]);
              self.$container.find('.content').css('min-height', '0');
            }
          }, 1000);
        }
      }


      /*$.ajax({
       url: 'http://dip.alibaba-inc.com/api/v2/services/schema/mock/6511?spm=a312q.7764190.0.0.OlXPLH',
       dataType: 'json',
       data: {
       page: self.currentPage++
       },
       success: function(data) {
       callback(data);
       }
       });*/
    },
    //事件绑定
    bindEvent: function() {
      var self = this;

      self.binded = true;

      self.$container.find('.J_MeiRiXinFaXianItems').removeClass('cdj-loading');

      if (!self.$loading && !this.conf.moduleinfo.waterfall) {
        self.$loading = $(
          '<li class="cdj-loading-item">\
            <div class="icon-circle"></div><span>加载中...</span>\
          </li>'
        );

        self.$container.find('.J_MeiRiXinFaXianItems .faxian-list').append(self.$loading);
      }

      self.loadMore();

      self.$container.show();

      var logMap = [
        ['/cdj.20.1', 'H1733391'],
        ['/cdj.20.2', 'H1733413'],
        ['/cdj.20.3', 'H1733414'],
        ['/cdj.20.4', 'H1733415'],
        ['/cdj.20.5', 'H1733416'],
        ['/cdj.20.6', 'H1733417'],
        ['/cdj.20.7', 'H1733418'],
        ['/cdj.20.8', 'H1733419'],
        ['/cdj.21.1', 'H1733391']
      ];

      self.$container.on('tap', '.item a', function(e) {
        var $cTarget = $(e.currentTarget);
        var $item = $cTarget.parents('.item');
        var url = $cTarget.attr('data-url');
        var spm = $(document.head).find('meta[name=spm-id]').attr('content') + '.' +
          $(document.body).attr('data-spm') + '.' + self.$container.attr('data-spm');
        var index = $item.index(), isGoldLog;

        // send gold log
        if ($cTarget.hasClass('entrance-link') || $cTarget.hasClass('slogan-link')) {
          var logKey = $(e.currentTarget).attr('data-log-key');
          var val = logMap[logKey];

          if (val) {
            goldlog && goldlog.record(val[0], '', '', val[1]);
          }

          isGoldLog = true;
        }

        // compute index
        if ($cTarget.hasClass('entrance-link')) {
          index = $cTarget.parent().index() + 3;
        } else {
          var hasEntrance = $cTarget.parents('.J_FaxianList').find('.entrance').length;

          if (index > 2 && hasEntrance) {
            index += 7;
          }
        }

        // complete spm and url
        spm += '.' + (index + 1);

        if (url.indexOf('?') !== -1) {
          url += '&spm=' + spm;
        } else {
          url += '?spm=' + spm;
        }

        // handle url
        if (isGoldLog) {
          setTimeout(function() {
            self.clickHandle(url);
          }, 100);
        } else {
          self.clickHandle(url);
        }
      });


      // 商品坑位 goldlog
      var glog2Map = [
        ['/cdj.22.1', 'H1733391'],
        ['/cdj.22.2', 'H1733413'],
        ['/cdj.22.3', 'H1733414'],
        ['/cdj.22.4', 'H1733415'],
        ['/cdj.22.5', 'H1733416'],
        ['/cdj.22.6', 'H1733417'],
        ['/cdj.22.7', 'H1733418'],
        ['/cdj.22.8', 'H1733419']
      ];

      self.$container.on('tap', '.item', function(e) {
        try {
          var $item = $(e.currentTarget);
          var index = $item.index();
          var hasEntrance = $item.parents('.J_FaxianList').find('.entrance').length;

          // send gold log
          if (hasEntrance) {
            if (3 < index && index < 6) {
              index -= 1;
            } else if (6 < index && index < 10) {
              index -= 2;
            }
          }

          var val = glog2Map[index];

          if (index < 8) {
            goldlog && goldlog.record(val[0], '', '', val[1]);
          }
        } catch (err) {
          console.log(err.stack);
        }
      });


      // waterfall 有歧义，这里指不使用瀑布流
      if (!self.conf.moduleinfo.waterfall) {
        var $list = self.$container.find('.J_MeiRiXinFaXianItems');

        $(document).on('scroll', self.ref = throttle(function(e) {
          var targetBottom = $list.offset().top + $list.height();
          var srcollTop = $('body').scrollTop();
          var windowHeight = $(window).height();
          var bottomLeft = targetBottom - srcollTop - windowHeight;

          //console.log(targetBottom, srcollTop, windowHeight, bottomLeft);

          if (bottomLeft < getPXByRem(2254 / 75) && !self.nomore) {
            self.loadMore();
          }
        }, 500, null, true));
      }

      if (navigator.userAgent.match(/iPhone/i)) {
        self.$container.addClass('lx-ios');
      }
    },
    clickHandle: function(url) {
      // 接入手淘
      if (window.navigator.userAgent.match(/WindVane/i)) {
        // UC 内核返回可保持之前浏览位置
        if (navigator.userAgent.match(/UCBrowser/i)) {
          location.href = url;
        } else {
          var params = {
            url: url
          };

          WindVane.call('Base', 'openWindow', params, function(e) {
          }, function(e) {
            locaiton.href = url;
          });
        }
      } else {
        location.href = url;
      }
    },
    loadMore: function(replace) {
      if (this.loading) {
        return;
      }

      this.loading = true;

      var self = this;

      //setTimeout(function() {
      self.loadData(function(data) {
        self.loading = false;

        if (data && data.length) {
          self.render({items: data}, replace);
        } else {
          if (self.$loading) {
            self.$loading.remove();
          }
          self.nomore = true;
          //$(document).off('scroll', self.ref);
          if (!$('.list-no-more')[0]) {
            self.$container.find('.J_MeiRiXinFaXianItems .faxian-list').append('<li class="list-no-more no-more">亲，已经看光光啦~</li>');
          }
        }
      });
      //}, 6000)
    },
    render: function(data, replace) {
      var self = this;

      if (self.$loading) {
        self.$loading.remove();
      }

      var html = jst(data);
      var $list = self.$container.find('.J_MeiRiXinFaXianItems .faxian-list');

      $list[replace ? 'html' : 'append'](html);
      $list.append(self.$loading);

      var config = {
        offsetY: 1366,
        // 同时最多加载的图片数量
        maxNum: 120,
        autoWebp: true,
        autoAnim: false
      };

      self.$container.find('.J_MeiRiXinFaXianItems img').lazyload(config);
    }
  };

  return Mod;


  function getPXByRem(rem) {
    try {
      var fontSize = parseFloat(getComputedStyle(document.documentElement)['font-size']);

      return rem * fontSize;
    } catch (e) {
      return rem * 32;
    }
  }

  // 节流阀 global
  function throttle(fn, interval, context, accurate) {
    var lastTime, timeout;

    if (accurate) {
      return function() {
        clearTimeout(timeout);

        var currentTime = new Date().getTime();
        var args = arguments;

        timeout = setTimeout(function() {
          fn.apply(context || null, Array.prototype.slice.call(args));
          lastTime = currentTime;
        }, interval - (currentTime - (lastTime || currentTime - interval)));
      };
    } else {
      return function() {
        var currentTime = new Date().getTime();
        var args = arguments;

        if (!lastTime || currentTime - lastTime >= interval) {
          fn.apply(context, Array.prototype.slice.call(args));
          lastTime = currentTime;
        }
      };
    }
  }

  function getQuery(url) {
    var search = url && url.split(/\?/)[1] || location.search;

    var queryArray = (decodeURI(search)).match(/[^&?]+=[^&]+/g) || [];

    for (var i = 0, queryObject = {}; i < queryArray.length; i++) {
      var kv = queryArray[i].split(/=/);

      queryObject[kv[0]] = kv[1];
    }
    return queryObject;
  }

  function getItemByKV(array, key, value) {
    for (var i = 0; i < array.length; ++i) {
      if (array[i][key] == value) {
        return array[i];
      }
    }
  }
});
