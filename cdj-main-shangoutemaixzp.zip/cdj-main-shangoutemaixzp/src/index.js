/**
 * @author {徐志鹏}({WB085727})
 * @version 0.0.1
 */
var define = window.define;
define(function(require) {
  var countDown = require('tbc/km-countdown');
  var jst = require('./items.jst.html');
  var XCtrl = require('tbc/m-xctrl/1.2.3/index');
  require('tbc/km-lazyload');
  function Mod() {
    this.init.apply(this, arguments);
    $(window).on('scroll', function() {
      var hei = $('#J_ShanGouTeMaiItems1').height();//商品高度
      var to = $('.cdj-main-shangoutemaixzp .module-wrap').offset().top;//距离顶部高度
      var hei2 = $('.cdj-main-shangoutemaixzp .head').height();//头部高度
      var oj = hei + to - hei2;//移动至多少高度才改变
      if ($(this).scrollTop() >= to) {
        $('#J_ShanGouTeMaiItems1').css('padding-top', hei2);
        $('.cdj-main-shangoutemaixzp .head').css({
          'position': 'fixed',
          'left': '0',
          'top': '0',
          'width': '100%',
          'z-index': '36'
        });
        if ($(this).scrollTop() >= oj) {
          var ii = $('#J_ShanGouTeMaiItems1').css('padding-top');
          $('.cdj-main-shangoutemaixzp .head').css({
            'position': 'absolute',
            'left': '0',
            'top': hei - hei2,
            'width': '100%',
            'z-index': '66'
          });
        }
        ;
      } else {
        $('#J_ShanGouTeMaiItems1').css('padding-top', '0');
        $('.cdj-main-shangoutemaixzp .head').css({
          'position': 'relative',
          'left': '0',
          'top': '0',
          'width': '100%',
          'z-index': '36'
        });
      }
      ;
    });
  }
  Mod.prototype = {
    init: function($container, conf) {
      var self = this;
      self.$container = $container;
      if (conf) {
        var data = $container.find('.module-wrap').data('schema');
        $('.cdj-main-shangoutemaixzp .xzp_topimg img').attr('src', data.moduleinfo.topimg + '_q50.jpg');
        self.loadData(conf);
      } else {
        var data = $container.find('.module-wrap').data('schema');
        $('.cdj-main-shangoutemaixzp .xzp_topimg img').attr('src', data.moduleinfo.topimg + '_q50.jpg');
        self.handleData(data.items);
      }
    },
    loadData: function(conf) {

      var self = this;
      XCtrl.dynamic(conf, 'items', function(data) {
        var  data = data.items;
        self.handleData(data);
      });
    },
    handleData: function(data) {
      //console.log(data)
      var schema = this.$container.find('.module-wrap').data('schema');
      this.$container.find('.module-wrap').data('schema', '');
      var correctItems = getCorrectItems(data, parseInt(this.$container.find('.module-wrap').data('now')));
      this.render(correctItems);
      this.bindEvent(correctItems);
    },
    render: function(data) {

      var htmlStr = jst(data);
      $('#J_ShanGouTeMaiItems1').html(htmlStr);
      var config = {
        offsetY: 1366,
        // 同时最多加载的图片数量
        maxNum: 120,
        autoWebp: true,
        autoAnim: false
      };
      $('#J_ShanGouTeMaiItems1 img').lazyload(config);
    },
    //事件绑定
    bindEvent: function(correct) {
      $('#J_ShanGouTeMaiItems1').removeClass('cdj-loading');
      if (correct.type == '2') {
        /*$('#J_SGTMCountDown').html('已经结束啦！');*/
        $('.cdj-main-shangoutemaixzp .module-wrap').css('display', 'none');
        return;
      }
      var txtMap = {
        '0': '距开始剩余时间',
        '1': '距结束剩余时间',
      };
      $('#J_SGTMCountDown1 span').html(txtMap[correct.type]);
      countDown({
        el: $('#J_SGTMCountDown1'),
        //stopPoint: parseDate('2015-09-06 22:00:00:00').getTime(),    // unix时间戳
        leftTime: correct.remain / 1000,      // or 剩余毫秒
        effect: 'slide' //动画效果 normal,slide,flip
      });
      var time1 = setInterval(function() {
        if ($('#J_SGTMCountDown1').text() == '距结束剩余时间：00天00时00分001秒') {
          $('.cdj-main-shangoutemaixzp .module-wrap').css('display', 'none');
          clearInterval(time1);
        }
      }, 2000);
    }
  };
  return Mod;
  function parseDate(dateStr) {
    var dateRegExp = /^(\d{4})\-([0-1]?[0-9])\-([0-3]?[0-9])\s+([0-2]?[0-9])\:([0-5]?[0-9])\:([0-5]?[0-9])(?:\:(\d{1,3}))?/;
    var matched = dateStr.match(dateRegExp);
    if (matched) {
      return new Date(
        parseInt(matched[1]),
        parseInt(matched[2]) - 1,
        parseInt(matched[3]),
        parseInt(matched[4]),
        parseInt(matched[5]),
        parseInt(matched[6]),
        parseInt(matched[7] || 0)
      );
    }
    return new Date();
  }

  // 获得正确的商品，剩余时间，状态（即将，正在，结束）
  function getCorrectItems(items, now) {
    // 开始时间升序
    items.sort(function(a, b) {
      return parseDate(a.item_content_start_time).getTime() - parseDate(b.item_content_start_time).getTime();
    });
    var tt = [];
    var target = {
      remain: 0,
      type: '0',
      items: null
    };
    for (var i = 0; i < items.length; i++) {
      var start = parseDate(items[i].item_content_start_time).getTime();
      var end = parseDate(items[i].item_content_end_time).getTime();
      var n = parseInt(parseDate(items[i].item_content_start_time).getFullYear());
      var y = parseInt(parseDate(items[i].item_content_start_time).getMonth() + 1);
      var r = parseInt(parseDate(items[i].item_content_start_time).getDate());
      var hh = n + '/' + y + '/' + r + ' ' + '00:00:00';
      var ksr = new Date(hh).getTime();
      if (ksr <= now && now < start) {
        items[i].zt = 1;
        tt.push(items[i]);
      } else if (now >= start && now < end) {
        items[i].zt = 2;
        tt.push(items[i]);
      }
      ;
    }
    ;
    if (tt.length == 0) {
      $('.cdj-main-shangoutemaixzp .module-wrap').css('display', 'none');
    }
    target.items = tt;
    //因为是按开始最早到最晚排列所以第一个是最早开始
    var start = parseDate(tt[0].item_content_start_time).getTime();
    var n = parseInt(parseDate(tt[0].item_content_start_time).getFullYear());
    var y = parseInt(parseDate(tt[0].item_content_start_time).getMonth() + 1);
    var r = parseInt(parseDate(tt[0].item_content_start_time).getDate());
    var hh = n + '/' + y + '/' + r + ' ' + '00:00:00';
    var ksr = new Date(hh).getTime();
    var end = null;

    function ed() {
      target.items.sort(function(a, b) {
        return parseDate(a.item_content_end_time).getTime() - parseDate(b.item_content_end_time).getTime();
      });
      end = parseDate(target.items[target.items.length - 1].item_content_end_time).getTime();
    }//让数据按结束时间从小到到排列 这样最后一个数据就是当天最晚的时间
    ed();
    // 未开始
    if (ksr <= now && now < start) {
      target.type = '0';
      target.remain = start - now;
      // 进行中
    } else if (start <= now && now < end) {
      target.type = '1';
      target.remain = end - now;
      // 还有促销，进入下一个循环
    } else if (i + 1 < items.length) {
      // 结束了
    } else {
      target.type = '2';
    }
    return target;
  }
});
